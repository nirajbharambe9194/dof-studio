# DoF Studio — Professional Depth of Field Simulator

A full-stack starter inspired by the interaction model of the reference Depth of Field Simulator, expanded with authentication, MySQL persistence, saved simulations, user preferences, cameras, lenses, presets, comparison mode, and a professional responsive UI.

## Stack
- Frontend: React + TypeScript + Vite + CSS
- Backend: Node.js + Express + TypeScript
- Database: MySQL + Prisma
- Auth: JWT + bcrypt
- Validation: Zod
- Charts/UI: Recharts + Lucide React

## Run with Docker
1. Copy `.env.example` to `.env`.
2. Run `docker compose up --build`.
3. Frontend: http://localhost:5173
4. API: http://localhost:4000

## Local development
### Backend
cd backend
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run dev

### Frontend
cd frontend
npm install
npm run dev

## Default database
MySQL database: `dof_studio`
user: `dof_user`
password: `dof_password`

Change these before production.

## Main features
- Register / login / logout
- JWT-protected API
- User profile and preferences
- Dark/light theme
- Metric/imperial display
- Camera and lens management
- Saved simulations
- Presets
- DoF calculations: hyperfocal, near limit, far limit, total DoF, FOV, magnification
- Live DoF visualization
- Comparison mode
- Responsive dashboard


## Professional camera/lens catalog

The Windows launcher seeds a broad multi-brand manufacturer catalog into MySQL. Catalog records are global and read-only; users can **Customize** any catalog item to create a private editable copy, or use **Add Custom** for equipment not included in the built-in catalog. See `CATALOG.md`.
