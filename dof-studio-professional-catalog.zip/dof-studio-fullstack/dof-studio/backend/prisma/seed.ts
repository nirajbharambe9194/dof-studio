import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

type CameraSeed = {
  manufacturer: string; model: string; sensorType: string; sensorWidth: number;
  sensorHeight: number; cropFactor: number; megapixels?: number; mount: string;
};
type LensSeed = {
  manufacturer: string; model: string; focalMin: number; focalMax: number;
  maxAperture: number; minFocusDistance?: number; mount: string;
};

const ff = (manufacturer:string, model:string, megapixels:number, mount:string):CameraSeed =>
  { manufacturer, model, sensorType:"Full Frame", sensorWidth:36, sensorHeight:24, cropFactor:1, megapixels, mount };
const apsc = (manufacturer:string, model:string, megapixels:number, mount:string):CameraSeed =>
  { manufacturer, model, sensorType:"APS-C", sensorWidth:23.5, sensorHeight:15.6, cropFactor:1.5, megapixels, mount };
const apscCanon = (manufacturer:string, model:string, megapixels:number, mount:string):CameraSeed =>
  { manufacturer, model, sensorType:"APS-C", sensorWidth:22.3, sensorHeight:14.9, cropFactor:1.6, megapixels, mount };
const m43 = (manufacturer:string, model:string, megapixels:number, mount:string):CameraSeed =>
  { manufacturer, model, sensorType:"Micro Four Thirds", sensorWidth:17.3, sensorHeight:13, cropFactor:2, megapixels, mount };
const medium = (manufacturer:string, model:string, megapixels:number, mount:string):CameraSeed =>
  { manufacturer, model, sensorType:"Medium Format", sensorWidth:43.8, sensorHeight:32.9, cropFactor:0.79, megapixels, mount };

const cameraRows:CameraSeed[] = [
  // Canon
  ff("Canon","EOS R1",24.2,"RF"), ff("Canon","EOS R5 Mark II",45,"RF"),
  ff("Canon","EOS R5",45,"RF"), ff("Canon","EOS R6 Mark II",24.2,"RF"),
  ff("Canon","EOS R6",20.1,"RF"), ff("Canon","EOS R8",24.2,"RF"),
  ff("Canon","EOS R",30.3,"RF"), ff("Canon","EOS RP",26.2,"RF"),
  apscCanon("Canon","EOS R7",32.5,"RF-S"), apscCanon("Canon","EOS R10",24.2,"RF-S"),
  apscCanon("Canon","EOS R50",24.2,"RF-S"), apscCanon("Canon","EOS R50 V",24.2,"RF-S"),
  apscCanon("Canon","EOS R100",24.1,"RF-S"),
  // Nikon
  ff("Nikon","Z9",45.7,"Z"), ff("Nikon","Z8",45.7,"Z"), ff("Nikon","Z7 II",45.7,"Z"),
  ff("Nikon","Z7",45.7,"Z"), ff("Nikon","Z6 III",24.5,"Z"), ff("Nikon","Z6 II",24.5,"Z"),
  ff("Nikon","Z6",24.5,"Z"), ff("Nikon","Z5 II",24.5,"Z"), ff("Nikon","Z5",24.3,"Z"),
  ff("Nikon","Zf",24.5,"Z"), ff("Nikon","Z fc",24.5,"Z"),
  apsc("Nikon","Z50 II",20.9,"Z"), apsc("Nikon","Z50",20.9,"Z"), apsc("Nikon","Z30",20.9,"Z"),
  apsc("Nikon","D500",20.9,"F"),
  // Sony
  ff("Sony","Alpha 1 II",50.1,"E"), ff("Sony","Alpha 1",50.1,"E"),
  ff("Sony","Alpha 9 III",24.6,"E"), ff("Sony","Alpha 9 II",24.2,"E"),
  ff("Sony","Alpha 7 V",33,"E"), ff("Sony","Alpha 7 IV",33,"E"),
  ff("Sony","Alpha 7 III",24.2,"E"), ff("Sony","Alpha 7C II",33,"E"),
  ff("Sony","Alpha 7CR",61,"E"), ff("Sony","Alpha 7R V",61,"E"),
  ff("Sony","Alpha 7R IV",61,"E"), ff("Sony","Alpha 7R III",42.4,"E"),
  ff("Sony","Alpha 7S III",12.1,"E"), ff("Sony","Alpha 7S II",12.2,"E"),
  apsc("Sony","Alpha 6700",26,"E"), apsc("Sony","Alpha 6600",24.2,"E"),
  apsc("Sony","Alpha 6400",24.2,"E"), apsc("Sony","ZV-E10 II",26,"E"),
  apsc("Sony","ZV-E10",24.2,"E"),
  // Fujifilm
  apsc("Fujifilm","X-T5",40.2,"X"), apsc("Fujifilm","X-T50",40.2,"X"),
  apsc("Fujifilm","X-H2",40.2,"X"), apsc("Fujifilm","X-H2S",26.1,"X"),
  apsc("Fujifilm","X-S20",26.1,"X"), apsc("Fujifilm","X-S10",26.1,"X"),
  apsc("Fujifilm","X-Pro3",26.1,"X"), apsc("Fujifilm","X100VI",40.2,"Fixed"),
  apsc("Fujifilm","X100V",26.1,"Fixed"), apsc("Fujifilm","X-M5",26.1,"X"),
  medium("Fujifilm","GFX100 II",102,"GFX"), medium("Fujifilm","GFX100S II",102,"GFX"),
  medium("Fujifilm","GFX50S II",51.4,"GFX"),
  // Panasonic
  ff("Panasonic","Lumix S1R II",44.3,"L"), ff("Panasonic","Lumix S1R",47.3,"L"),
  ff("Panasonic","Lumix S1 II",24.2,"L"), ff("Panasonic","Lumix S1",24.2,"L"),
  ff("Panasonic","Lumix S5 II",24.2,"L"), ff("Panasonic","Lumix S5 IIX",24.2,"L"),
  ff("Panasonic","Lumix S5",24.2,"L"), ff("Panasonic","Lumix S9",24.2,"L"),
  m43("Panasonic","Lumix GH7",25.2,"Micro Four Thirds"), m43("Panasonic","Lumix GH6",25.2,"Micro Four Thirds"),
  m43("Panasonic","Lumix G9 II",25.2,"Micro Four Thirds"), m43("Panasonic","Lumix G100D",20.3,"Micro Four Thirds"),
  // OM System / Olympus
  m43("OM System","OM-1 Mark II",20.4,"Micro Four Thirds"), m43("OM System","OM-1",20.4,"Micro Four Thirds"),
  m43("OM System","OM-5",20.4,"Micro Four Thirds"), m43("OM System","OM-3",20.4,"Micro Four Thirds"),
  m43("Olympus","OM-D E-M1 Mark III",20.4,"Micro Four Thirds"), m43("Olympus","OM-D E-M10 IV",20.3,"Micro Four Thirds"),
  // Leica
  ff("Leica","SL3-S",24.6,"L"), ff("Leica","SL3",60.3,"L"), ff("Leica","M11",60.3,"M"),
  ff("Leica","M11-P",60.3,"M"), ff("Leica","Q3",60.3,"Fixed"), ff("Leica","Q3 43",60.3,"Fixed"),
  apsc("Leica","CL",24.2,"L-Mount"),
  // Sigma
  ff("Sigma","fp",24.6,"L"), ff("Sigma","fp L",61,"L"),
  // Pentax
  apsc("Pentax","K-3 Mark III",25.7,"K"), apsc("Pentax","KF",24.2,"K"),
  // Hasselblad
  medium("Hasselblad","X2D 100C",100,"XCD"), medium("Hasselblad","X2D II 100C",100,"XCD"),
  medium("Hasselblad","907X CFV 100C",100,"XCD"), medium("Hasselblad","907X CFV II 50C",50,"XCD"),
];

const lensRows:LensSeed[] = [
  // Canon RF
  ["Canon","RF 15-35mm F2.8 L IS USM",15,35,2.8,0.28,"RF"],
  ["Canon","RF 14-35mm F4 L IS USM",14,35,4,0.2,"RF"],
  ["Canon","RF 16mm F2.8 STM",16,16,2.8,0.13,"RF"],
  ["Canon","RF 24mm F1.4 L VCM",24,24,1.4,0.24,"RF"],
  ["Canon","RF 28mm F2.8 STM",28,28,2.8,0.23,"RF"],
  ["Canon","RF 35mm F1.4 L VCM",35,35,1.4,0.28,"RF"],
  ["Canon","RF 35mm F1.8 Macro IS STM",35,35,1.8,0.17,"RF"],
  ["Canon","RF 50mm F1.2 L USM",50,50,1.2,0.4,"RF"],
  ["Canon","RF 50mm F1.8 STM",50,50,1.8,0.3,"RF"],
  ["Canon","RF 85mm F1.2 L USM",85,85,1.2,0.85,"RF"],
  ["Canon","RF 85mm F2 Macro IS STM",85,85,2,0.35,"RF"],
  ["Canon","RF 100mm F2.8 L Macro IS USM",100,100,2.8,0.26,"RF"],
  ["Canon","RF 135mm F1.8 L IS USM",135,135,1.8,0.7,"RF"],
  ["Canon","RF 200mm F2 L IS USM",200,200,2,1.8,"RF"],
  ["Canon","RF 24-70mm F2.8 L IS USM",24,70,2.8,0.21,"RF"],
  ["Canon","RF 24-105mm F4 L IS USM",24,105,4,0.45,"RF"],
  ["Canon","RF 24-240mm F4-6.3 IS USM",24,240,4,0.5,"RF"],
  ["Canon","RF 70-200mm F2.8 L IS USM",70,200,2.8,0.7,"RF"],
  ["Canon","RF 70-200mm F4 L IS USM",70,200,4,0.6,"RF"],
  ["Canon","RF 100-500mm F4.5-7.1 L IS USM",100,500,4.5,0.9,"RF"],
  ["Canon","RF 200-800mm F6.3-9 IS USM",200,800,6.3,0.8,"RF"],
  // Nikon Z
  ["Nikon","NIKKOR Z 14-24mm f/2.8 S",14,24,2.8,0.28,"Z"],
  ["Nikon","NIKKOR Z 14-30mm f/4 S",14,30,4,0.28,"Z"],
  ["Nikon","NIKKOR Z 20mm f/1.8 S",20,20,1.8,0.2,"Z"],
  ["Nikon","NIKKOR Z 24mm f/1.8 S",24,24,1.8,0.25,"Z"],
  ["Nikon","NIKKOR Z 28mm f/2.8",28,28,2.8,0.19,"Z"],
  ["Nikon","NIKKOR Z 35mm f/1.8 S",35,35,1.8,0.25,"Z"],
  ["Nikon","NIKKOR Z 50mm f/1.2 S",50,50,1.2,0.45,"Z"],
  ["Nikon","NIKKOR Z 50mm f/1.8 S",50,50,1.8,0.4,"Z"],
  ["Nikon","NIKKOR Z 58mm f/0.95 S Noct",58,58,0.95,0.5,"Z"],
  ["Nikon","NIKKOR Z 85mm f/1.2 S",85,85,1.2,0.85,"Z"],
  ["Nikon","NIKKOR Z 85mm f/1.8 S",85,85,1.8,0.8,"Z"],
  ["Nikon","NIKKOR Z MC 105mm f/2.8 VR S",105,105,2.8,0.29,"Z"],
  ["Nikon","NIKKOR Z 135mm f/1.8 S Plena",135,135,1.8,0.82,"Z"],
  ["Nikon","NIKKOR Z 24-70mm f/2.8 S",24,70,2.8,0.38,"Z"],
  ["Nikon","NIKKOR Z 24-120mm f/4 S",24,120,4,0.35,"Z"],
  ["Nikon","NIKKOR Z 28-75mm f/2.8",28,75,2.8,0.19,"Z"],
  ["Nikon","NIKKOR Z 70-200mm f/2.8 VR S",70,200,2.8,0.5,"Z"],
  ["Nikon","NIKKOR Z 100-400mm f/4.5-5.6 VR S",100,400,4.5,0.75,"Z"],
  ["Nikon","NIKKOR Z 180-600mm f/5.6-6.3 VR",180,600,5.6,1.3,"Z"],
  ["Nikon","NIKKOR Z 600mm f/4 TC VR S",600,600,4,4.3,"Z"],
  // Sony E
  ["Sony","FE 12-24mm F2.8 GM",12,24,2.8,0.28,"E"],
  ["Sony","FE 14mm F1.8 GM",14,14,1.8,0.25,"E"],
  ["Sony","FE 20mm F1.8 G",20,20,1.8,0.18,"E"],
  ["Sony","FE 24mm F1.4 GM",24,24,1.4,0.24,"E"],
  ["Sony","FE 24mm F2.8 G",24,24,2.8,0.24,"E"],
  ["Sony","FE 35mm F1.4 GM",35,35,1.4,0.27,"E"],
  ["Sony","FE 35mm F1.8",35,35,1.8,0.22,"E"],
  ["Sony","FE 50mm F1.2 GM",50,50,1.2,0.4,"E"],
  ["Sony","FE 50mm F1.4 GM",50,50,1.4,0.41,"E"],
  ["Sony","FE 50mm F1.8",50,50,1.8,0.45,"E"],
  ["Sony","FE 85mm F1.4 GM II",85,85,1.4,0.85,"E"],
  ["Sony","FE 85mm F1.8",85,85,1.8,0.8,"E"],
  ["Sony","FE 90mm F2.8 Macro G OSS",90,90,2.8,0.28,"E"],
  ["Sony","FE 135mm F1.8 GM",135,135,1.8,0.7,"E"],
  ["Sony","FE 24-70mm F2.8 GM II",24,70,2.8,0.21,"E"],
  ["Sony","FE 20-70mm F4 G",20,70,4,0.3,"E"],
  ["Sony","FE 24-105mm F4 G OSS",24,105,4,0.38,"E"],
  ["Sony","FE 70-200mm F2.8 GM OSS II",70,200,2.8,0.4,"E"],
  ["Sony","FE 100-400mm GM OSS",100,400,4.5,0.98,"E"],
  ["Sony","FE 200-600mm G OSS",200,600,5.6,2.4,"E"],
  // Fujifilm X
  ["Fujifilm","XF 8-16mm F2.8 R LM WR",8,16,2.8,0.25,"X"],
  ["Fujifilm","XF 10-24mm F4 R OIS WR",10,24,4,0.24,"X"],
  ["Fujifilm","XF 16mm F1.4 R WR",16,16,1.4,0.15,"X"],
  ["Fujifilm","XF 18mm F1.4 R LM WR",18,18,1.4,0.2,"X"],
  ["Fujifilm","XF 23mm F1.4 R LM WR",23,23,1.4,0.28,"X"],
  ["Fujifilm","XF 27mm F2.8 R WR",27,27,2.8,0.34,"X"],
  ["Fujifilm","XF 33mm F1.4 R LM WR",33,33,1.4,0.3,"X"],
  ["Fujifilm","XF 35mm F1.4 R",35,35,1.4,0.28,"X"],
  ["Fujifilm","XF 50mm F1.0 R WR",50,50,1,0.7,"X"],
  ["Fujifilm","XF 56mm F1.2 R WR",56,56,1.2,0.5,"X"],
  ["Fujifilm","XF 80mm F2.8 R LM OIS WR Macro",80,80,2.8,0.25,"X"],
  ["Fujifilm","XF 90mm F2 R LM WR",90,90,2,0.6,"X"],
  ["Fujifilm","XF 16-55mm F2.8 R LM WR II",16,55,2.8,0.3,"X"],
  ["Fujifilm","XF 18-55mm F2.8-4 R LM OIS",18,55,2.8,0.3,"X"],
  ["Fujifilm","XF 50-140mm F2.8 R LM OIS WR",50,140,2.8,1,"X"],
  ["Fujifilm","XF 70-300mm F4-5.6 R LM OIS WR",70,300,4,0.83,"X"],
  // L mount / Panasonic / Leica / Sigma
  ["Panasonic","Lumix S 18mm F1.8",18,18,1.8,0.18,"L"],
  ["Panasonic","Lumix S 24mm F1.8",24,24,1.8,0.24,"L"],
  ["Panasonic","Lumix S 35mm F1.8",35,35,1.8,0.24,"L"],
  ["Panasonic","Lumix S 50mm F1.8",50,50,1.8,0.45,"L"],
  ["Panasonic","Lumix S 85mm F1.8",85,85,1.8,0.8,"L"],
  ["Panasonic","Lumix S Pro 24-70mm F2.8",24,70,2.8,0.37,"L"],
  ["Panasonic","Lumix S Pro 70-200mm F2.8 O.I.S.",70,200,2.8,0.95,"L"],
  ["Leica","APO-Summicron-SL 35mm f/2 ASPH.",35,35,2,0.3,"L"],
  ["Leica","APO-Summicron-SL 50mm f/2 ASPH.",50,50,2,0.45,"L"],
  ["Leica","APO-Summicron-SL 75mm f/2 ASPH.",75,75,2,0.5,"L"],
  ["Leica","Vario-Elmarit-SL 24-90mm f/2.8-4 ASPH.",24,90,2.8,0.3,"L"],
  ["Sigma","24mm F1.4 DG DN Art",24,24,1.4,0.25,"L/E"],
  ["Sigma","35mm F1.4 DG DN Art",35,35,1.4,0.3,"L/E"],
  ["Sigma","50mm F1.2 DG DN Art",50,50,1.2,0.4,"L/E"],
  ["Sigma","85mm F1.4 DG DN Art",85,85,1.4,0.85,"L/E"],
  ["Sigma","105mm F2.8 DG DN Macro Art",105,105,2.8,0.3,"L/E"],
  ["Sigma","24-70mm F2.8 DG DN II Art",24,70,2.8,0.34,"L/E"],
  ["Sigma","70-200mm F2.8 DG DN OS Sports",70,200,2.8,0.65,"L/E"],
  // MFT
  ["OM System","M.Zuiko Digital ED 7-14mm F2.8 PRO",7,14,2.8,0.2,"Micro Four Thirds"],
  ["OM System","M.Zuiko Digital ED 12-40mm F2.8 PRO II",12,40,2.8,0.2,"Micro Four Thirds"],
  ["OM System","M.Zuiko Digital ED 17mm F1.2 PRO",17,17,1.2,0.2,"Micro Four Thirds"],
  ["OM System","M.Zuiko Digital ED 25mm F1.2 PRO",25,25,1.2,0.3,"Micro Four Thirds"],
  ["OM System","M.Zuiko Digital ED 45mm F1.2 PRO",45,45,1.2,0.5,"Micro Four Thirds"],
  ["OM System","M.Zuiko Digital ED 60mm F2.8 Macro",60,60,2.8,0.19,"Micro Four Thirds"],
  ["Panasonic","Leica DG Vario-Summilux 10-25mm F1.7",10,25,1.7,0.28,"Micro Four Thirds"],
  ["Panasonic","Leica DG Vario-Elmarit 12-35mm F2.8",12,35,2.8,0.15,"Micro Four Thirds"],
  ["Panasonic","Leica DG Nocticron 42.5mm F1.2",42.5,42.5,1.2,0.5,"Micro Four Thirds"],
  // Pentax / medium format
  ["Pentax","HD PENTAX-DA 11-18mm F2.8 ED DC AW",11,18,2.8,0.3,"K"],
  ["Pentax","HD PENTAX-DA* 16-50mm F2.8 ED PLM AW",16,50,2.8,0.3,"K"],
  ["Pentax","HD PENTAX-DA* 50-135mm F2.8 ED PLM AW",50,135,2.8,1,"K"],
  ["Hasselblad","XCD 25V",25,25,2.5,0.25,"XCD"],
  ["Hasselblad","XCD 28P",28,28,4,0.23,"XCD"],
  ["Hasselblad","XCD 30mm F3.5",30,30,3.5,0.32,"XCD"],
  ["Hasselblad","XCD 38V",38,38,2.5,0.4,"XCD"],
  ["Hasselblad","XCD 45P",45,45,4,0.35,"XCD"],
  ["Hasselblad","XCD 55V",55,55,2.5,0.45,"XCD"],
  ["Hasselblad","XCD 80mm F1.9",80,80,1.9,0.7,"XCD"],
  ["Hasselblad","XCD 90V",90,90,2.5,0.67,"XCD"],
  ["Hasselblad","XCD 120mm F3.5 Macro",120,120,3.5,0.43,"XCD"],
  ["Hasselblad","XCD 135mm F2.5",135,135,2.5,1,"XCD"],
  ["Hasselblad","XCD 90mm F3.2",90,90,3.2,0.67,"XCD"],
];

const cameras = cameraRows;
const lenses = lensRows.map(([manufacturer,model,focalMin,focalMax,maxAperture,minFocusDistance,mount]) =>
  ({manufacturer,model,focalMin,focalMax,maxAperture,minFocusDistance,mount} as LensSeed)
);

async function main() {
  console.log(`Seeding professional catalog: ${cameras.length} cameras, ${lenses.length} lenses`);

  // Catalog records are global (userId = null). Existing global catalog rows are updated.
  for (const c of cameras) {
    const name = `${c.manufacturer} ${c.model}`;
    const existing = await prisma.camera.findFirst({
      where: { userId: null, manufacturer: c.manufacturer, model: c.model }
    });
    const data = { name, ...c, isCatalog: true, userId: null };
    if (existing) await prisma.camera.update({ where: { id: existing.id }, data });
    else await prisma.camera.create({ data });
  }

  for (const l of lenses) {
    const name = `${l.manufacturer} ${l.model}`;
    const existing = await prisma.lens.findFirst({
      where: { userId: null, manufacturer: l.manufacturer, model: l.model }
    });
    const data = {
      name, ...l, isCatalog: true, userId: null,
      minFocusDistance: l.minFocusDistance ?? 0.5
    };
    if (existing) await prisma.lens.update({ where: { id: existing.id }, data });
    else await prisma.lens.create({ data });
  }

  console.log("Catalog seeding complete.");
}

main().catch(e => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
