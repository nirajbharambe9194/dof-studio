import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { PrismaClient } from "@prisma/client";
import { z } from "zod";

dotenv.config();
const prisma = new PrismaClient();
const app = express();
app.use(cors({ origin: process.env.CORS_ORIGIN?.split(",") ?? "*" }));
app.use(express.json());

const JWT_SECRET = process.env.JWT_SECRET || "development-secret";

type AuthRequest = express.Request & { userId?: number };

function auth(req: AuthRequest, res: express.Response, next: express.NextFunction) {
  const token = req.headers.authorization?.replace("Bearer ", "");
  if (!token) return res.status(401).json({ message: "Authentication required" });
  try {
    const payload = jwt.verify(token, JWT_SECRET) as { userId: number };
    req.userId = payload.userId;
    next();
  } catch {
    return res.status(401).json({ message: "Invalid or expired token" });
  }
}

const registerSchema = z.object({
  name: z.string().min(2).max(100),
  email: z.email(),
  password: z.string().min(8).max(128)
});

const loginSchema = z.object({
  email: z.email(),
  password: z.string().min(1)
});

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "dof-studio-api" }));

app.post("/api/auth/register", async (req, res) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Invalid registration data" });
  const { name, email, password } = parsed.data;
  const exists = await prisma.user.findUnique({ where: { email } });
  if (exists) return res.status(409).json({ message: "Email already registered" });
  const passwordHash = await bcrypt.hash(password, 12);
  const user = await prisma.user.create({
    data: { name, email, passwordHash, settings: { create: {} } },
    select: { id: true, name: true, email: true, role: true }
  });
  const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: "7d" });
  res.status(201).json({ token, user });
});

app.post("/api/auth/login", async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Invalid login data" });
  const user = await prisma.user.findUnique({ where: { email: parsed.data.email } });
  if (!user || !(await bcrypt.compare(parsed.data.password, user.passwordHash)))
    return res.status(401).json({ message: "Invalid email or password" });
  const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: "7d" });
  res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
});

app.get("/api/me", auth, async (req: AuthRequest, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.userId },
    select: { id: true, name: true, email: true, role: true, settings: true }
  });
  res.json(user);
});

app.put("/api/settings", auth, async (req: AuthRequest, res) => {
  const settings = await prisma.userSettings.upsert({
    where: { userId: req.userId! },
    update: req.body,
    create: { userId: req.userId!, ...req.body }
  });
  res.json(settings);
});

app.get("/api/cameras", auth, async (req: AuthRequest, res) => {
  const rows = await prisma.camera.findMany({
    where: { OR: [{ isCatalog: true }, { userId: req.userId! }] },
    orderBy: [{ isCatalog: "desc" }, { manufacturer: "asc" }, { name: "asc" }]
  });
  res.json(rows);
});
app.post("/api/cameras", auth, async (req: AuthRequest, res) => {
  const data = {
    name: String(req.body.name || `${req.body.manufacturer || ""} ${req.body.model || ""}`).trim(),
    manufacturer: req.body.manufacturer ? String(req.body.manufacturer) : null,
    model: req.body.model ? String(req.body.model) : null,
    sensorType: String(req.body.sensorType || "Full Frame"),
    sensorWidth: Number(req.body.sensorWidth || 36),
    sensorHeight: Number(req.body.sensorHeight || 24),
    cropFactor: Number(req.body.cropFactor || 1),
    megapixels: req.body.megapixels == null ? null : Number(req.body.megapixels),
    mount: req.body.mount ? String(req.body.mount) : null,
    userId: req.userId!, isCatalog: false
  };
  res.status(201).json(await prisma.camera.create({ data }));
});
app.put("/api/cameras/:id", auth, async (req: AuthRequest, res) => {
  const id = Number(req.params.id);
  const own = await prisma.camera.findFirst({ where: { id, userId: req.userId! } });
  if (!own) return res.status(404).json({ message: "Custom camera not found" });
  res.json(await prisma.camera.update({ where: { id }, data: { ...req.body, userId: req.userId!, isCatalog: false } }));
});
app.delete("/api/cameras/:id", auth, async (req: AuthRequest, res) => {
  await prisma.camera.deleteMany({ where: { id: Number(req.params.id), userId: req.userId! } });
  res.status(204).send();
});

app.get("/api/lenses", auth, async (req: AuthRequest, res) => {
  const rows = await prisma.lens.findMany({
    where: { OR: [{ isCatalog: true }, { userId: req.userId! }] },
    orderBy: [{ isCatalog: "desc" }, { manufacturer: "asc" }, { name: "asc" }]
  });
  res.json(rows);
});
app.post("/api/lenses", auth, async (req: AuthRequest, res) => {
  const data = {
    name: String(req.body.name || `${req.body.manufacturer || ""} ${req.body.model || ""}`).trim(),
    manufacturer: req.body.manufacturer ? String(req.body.manufacturer) : null,
    model: req.body.model ? String(req.body.model) : null,
    focalMin: Number(req.body.focalMin || 50),
    focalMax: Number(req.body.focalMax || req.body.focalMin || 50),
    maxAperture: Number(req.body.maxAperture || 2.8),
    minFocusDistance: Number(req.body.minFocusDistance || 0.5),
    mount: req.body.mount ? String(req.body.mount) : null,
    userId: req.userId!, isCatalog: false
  };
  res.status(201).json(await prisma.lens.create({ data }));
});
app.put("/api/lenses/:id", auth, async (req: AuthRequest, res) => {
  const id = Number(req.params.id);
  const own = await prisma.lens.findFirst({ where: { id, userId: req.userId! } });
  if (!own) return res.status(404).json({ message: "Custom lens not found" });
  res.json(await prisma.lens.update({ where: { id }, data: { ...req.body, userId: req.userId!, isCatalog: false } }));
});
app.delete("/api/lenses/:id", auth, async (req: AuthRequest, res) => {
  await prisma.lens.deleteMany({ where: { id: Number(req.params.id), userId: req.userId! } });
  res.status(204).send();
});

app.get("/api/simulations", auth, async (req: AuthRequest, res) => {
  res.json(await prisma.simulation.findMany({ where: { userId: req.userId }, orderBy: { updatedAt: "desc" } }));
});
app.post("/api/simulations", auth, async (req: AuthRequest, res) => {
  res.status(201).json(await prisma.simulation.create({ data: { ...req.body, userId: req.userId! } }));
});
app.delete("/api/simulations/:id", auth, async (req: AuthRequest, res) => {
  await prisma.simulation.deleteMany({ where: { id: Number(req.params.id), userId: req.userId } });
  res.status(204).send();
});

app.get("/api/presets", auth, async (req: AuthRequest, res) => {
  res.json(await prisma.preset.findMany({ where: { userId: req.userId }, orderBy: { createdAt: "desc" } }));
});
app.post("/api/presets", auth, async (req: AuthRequest, res) => {
  res.status(201).json(await prisma.preset.create({ data: { ...req.body, userId: req.userId! } }));
});

const port = Number(process.env.PORT || 4000);
app.listen(port, () => console.log(`DoF Studio API listening on :${port}`));
