import React, { useEffect, useMemo, useState } from "react";
import {
  Aperture, Camera, ChartNoAxesCombined, ChevronRight, CircleUserRound,
  CloudSun, Database, Download, Focus, Gauge, Layers3, LogIn, LogOut,
  Menu, Moon, Save, Settings, Sparkles, Sun, Target, Trash2, UserPlus, X, Plus, Search, Copy, Pencil
} from "lucide-react";
import { api } from "./api";
import { calculate, DofSettings, presets } from "./calculations";

type User = { id:number; name:string; email:string; role:string; settings?:any };

const defaultSettings: DofSettings = {
  focalLength: 50, aperture: 2.8, focusDistance: 3, sensorWidth: 36, sensorHeight: 24
};

function fmt(n:number) {
  if (!Number.isFinite(n)) return "∞";
  if (n < 1) return `${n.toFixed(3)} m`;
  return `${n.toFixed(2)} m`;
}

export default function App() {
  const [user, setUser] = useState<User|null>(null);
  const [authMode, setAuthMode] = useState<"login"|"register">("login");
  const [authOpen, setAuthOpen] = useState(true);
  const [authError, setAuthError] = useState("");
  const [form, setForm] = useState({name:"", email:"", password:""});
  const [settings, setSettings] = useState<DofSettings>(defaultSettings);
  const [active, setActive] = useState("Simulator");
  const [theme, setTheme] = useState<"dark"|"light">("dark");
  const [mobileNav, setMobileNav] = useState(false);
  const [saved, setSaved] = useState<any[]>([]);
  const [comparison, setComparison] = useState<any[]>([]);
  const [message, setMessage] = useState("");

  const result = useMemo(() => calculate(settings), [settings]);

  useEffect(() => {
    const token = localStorage.getItem("dof_token");
    if (!token) return;
    api("/me").then((u) => { setUser(u); setAuthOpen(false); setTheme(u.settings?.theme || "dark"); }).catch(() => localStorage.removeItem("dof_token"));
  }, []);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  useEffect(() => {
    if (user) api("/simulations").then(setSaved).catch(()=>{});
  }, [user]);

  async function submitAuth(e:React.FormEvent) {
    e.preventDefault(); setAuthError("");
    try {
      const endpoint = authMode === "login" ? "/auth/login" : "/auth/register";
      const data = await api(endpoint, {method:"POST", body:JSON.stringify(form)});
      localStorage.setItem("dof_token", data.token);
      setUser(data.user); setAuthOpen(false);
    } catch (e:any) { setAuthError(e.message); }
  }

  function logout() {
    localStorage.removeItem("dof_token"); setUser(null); setAuthOpen(true); setAuthMode("login");
  }

  async function saveSimulation() {
    if (!user) return;
    const data = {
      name: `${settings.focalLength}mm • f/${settings.aperture} • ${settings.focusDistance}m`,
      ...settings,
      coc: result.coc, nearLimit: result.nearLimit, farLimit: Number.isFinite(result.farLimit)?result.farLimit:null,
      totalDof: Number.isFinite(result.totalDof)?result.totalDof:null, hyperfocal: result.hyperfocal,
      fov: result.fov, magnification: result.magnification, configuration: settings
    };
    const created = await api("/simulations", {method:"POST", body:JSON.stringify(data)});
    setSaved((x)=>[created,...x]); setMessage("Simulation saved to your account.");
    setTimeout(()=>setMessage(""), 2500);
  }

  function loadPreset(p:any) {
    setSettings({focalLength:p.focalLength, aperture:p.aperture, focusDistance:p.focusDistance, sensorWidth:p.sensorWidth, sensorHeight:p.sensorHeight});
    setActive("Simulator");
  }

  async function deleteSaved(id:number) {
    await api(`/simulations/${id}`, {method:"DELETE"});
    setSaved(x=>x.filter(s=>s.id!==id));
  }

  function addComparison() {
    setComparison(x => [...x.slice(-1), {settings, result, label:`Setup ${x.length+1}`}]);
  }

  if (authOpen || !user) return (
    <div className="auth-shell">
      <div className="auth-visual">
        <div className="brand"><Aperture size={28}/> <span>DoF<span className="accent">Studio</span></span></div>
        <div className="hero-copy">
          <p className="eyebrow">PROFESSIONAL OPTICAL WORKSPACE</p>
          <h1>See your focus.<br/><em>Shape your image.</em></h1>
          <p>Explore depth of field with precision controls, optical calculations, saved camera setups and a visual focus map.</p>
          <div className="hero-stats"><span><b>∞</b> Focus range</span><span><b>3D</b> Visual analysis</span><span><b>MySQL</b> Cloud-ready</span></div>
        </div>
      </div>
      <form className="auth-card" onSubmit={submitAuth}>
        <div className="auth-top">
          <div><p className="eyebrow">{authMode==="login"?"WELCOME BACK":"CREATE YOUR WORKSPACE"}</p><h2>{authMode==="login"?"Sign in":"Create account"}</h2></div>
          {authMode==="login"?<UserPlus/>:<LogIn/>}
        </div>
        {authMode==="register" && <label>Name<input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Your name"/></label>}
        <label>Email<input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="you@example.com"/></label>
        <label>Password<input type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} placeholder="Minimum 8 characters"/></label>
        {authError && <div className="error">{authError}</div>}
        <button className="primary wide">{authMode==="login"?"Sign in to DoF Studio":"Create workspace"} <ChevronRight size={18}/></button>
        <button type="button" className="link-btn" onClick={()=>setAuthMode(authMode==="login"?"register":"login")}>
          {authMode==="login"?"New here? Create an account":"Already have an account? Sign in"}
        </button>
        <p className="legal">Your simulations, preferences, cameras and lenses are stored privately under your account.</p>
      </form>
    </div>
  );

  const nav = [
    ["Simulator", <Focus/>], ["Saved Projects", <Save/>], ["Presets", <Sparkles/>],
    ["Cameras & Lenses", <Camera/>], ["Analytics", <ChartNoAxesCombined/>], ["Settings", <Settings/>]
  ];

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand"><Aperture size={25}/> <span>DoF<span className="accent">Studio</span></span></div>
        <div className="top-actions">
          <button className="icon-btn" onClick={()=>setTheme(theme==="dark"?"light":"dark")} title="Toggle theme">{theme==="dark"?<Sun/>:<Moon/>}</button>
          <div className="user-pill"><CircleUserRound/><span>{user.name}</span></div>
          <button className="icon-btn" onClick={logout} title="Logout"><LogOut/></button>
          <button className="mobile-menu icon-btn" onClick={()=>setMobileNav(!mobileNav)}>{mobileNav?<X/>:<Menu/>}</button>
        </div>
      </header>
      <div className="body">
        <aside className={mobileNav?"sidebar open":"sidebar"}>
          <div className="workspace-label">WORKSPACE</div>
          {nav.map(([label,icon])=><button key={label as string} className={active===label?"nav active":"nav"} onClick={()=>{setActive(label as string);setMobileNav(false)}}>{icon}<span>{label}</span>{active===label&&<span className="nav-dot"/>}</button>)}
          <div className="sidebar-bottom">
            <div className="storage"><Database size={16}/><div><span>Personal workspace</span><small>MySQL synced</small></div></div>
            <button className="nav" onClick={logout}><LogOut/><span>Sign out</span></button>
          </div>
        </aside>

        <main className="main">
          {message && <div className="toast">{message}</div>}
          <div className="page-head">
            <div><p className="eyebrow">OPTICAL WORKBENCH</p><h1>{active}</h1><p className="sub">{active==="Simulator"?"Tune your lens and see exactly where your image is sharp.":"Manage your personal photography workspace."}</p></div>
            {active==="Simulator" && <div className="head-actions"><button className="secondary" onClick={addComparison}><Layers3 size={17}/> Compare</button><button className="primary" onClick={saveSimulation}><Save size={17}/> Save</button></div>}
          </div>

          {active==="Simulator" && <Simulator settings={settings} setSettings={setSettings} result={result} comparison={comparison}/>}
          {active==="Saved Projects" && <Saved saved={saved} load={(s:any)=>{setSettings(s.configuration);setActive("Simulator")}} remove={deleteSaved}/>}
          {active==="Presets" && <Presets load={loadPreset}/>}
          {active==="Cameras & Lenses" && <Catalog/>}
          {active==="Analytics" && <Analytics saved={saved}/>}
          {active==="Settings" && <SettingsPanel theme={theme} setTheme={async(t:any)=>{setTheme(t);await api("/settings",{method:"PUT",body:JSON.stringify({theme:t})})}} user={user}/>}
        </main>
      </div>
    </div>
  );
}

function Slider({label,value,min,max,step,onChange,unit=""}:{label:string,value:number,min:number,max:number,step:number,onChange:(n:number)=>void,unit?:string}) {
  return <div className="slider-row"><div className="slider-label"><span>{label}</span><b>{value}{unit}</b></div><input type="range" min={min} max={max} step={step} value={value} onChange={e=>onChange(Number(e.target.value))}/><div className="range-end"><span>{min}{unit}</span><span>{max}{unit}</span></div></div>
}

function Simulator({settings,setSettings,result,comparison}:{settings:DofSettings,setSettings:React.Dispatch<React.SetStateAction<DofSettings>>,result:any,comparison:any[]}) {
  const update=(key:keyof DofSettings)=>(v:number)=>setSettings(s=>({...s,[key]:v}));
  return <div className="sim-grid">
    <section className="control-card card">
      <div className="card-head"><div><p className="eyebrow">CAMERA & LENS</p><h3>Exposure controls</h3></div><Camera size={20}/></div>
      <div className="control-section"><h4>Lens</h4><Slider label="Focal length" value={settings.focalLength} min={14} max={400} step={1} onChange={update("focalLength")} unit=" mm"/><Slider label="Aperture" value={settings.aperture} min={0.95} max={22} step={0.1} onChange={update("aperture")} unit=""/><div className="aperture-readout">f/{settings.aperture.toFixed(1)}</div></div>
      <div className="control-section"><h4>Focus</h4><Slider label="Focus distance" value={settings.focusDistance} min={0.2} max={50} step={0.1} onChange={update("focusDistance")} unit=" m"/></div>
      <div className="control-section"><h4>Sensor</h4><div className="select-row"><button className={settings.sensorWidth===36?"selected":""} onClick={()=>setSettings(s=>({...s,sensorWidth:36,sensorHeight:24}))}>Full Frame</button><button className={settings.sensorWidth===23.5?"selected":""} onClick={()=>setSettings(s=>({...s,sensorWidth:23.5,sensorHeight:15.6}))}>APS-C</button><button className={settings.sensorWidth===17.3?"selected":""} onClick={()=>setSettings(s=>({...s,sensorWidth:17.3,sensorHeight:13}))}>MFT</button></div></div>
      <div className="quick-presets"><span>QUICK START</span><div>{presets.slice(0,4).map(p=><button key={p.name} onClick={()=>setSettings({focalLength:p.focalLength,aperture:p.aperture,focusDistance:p.focusDistance,sensorWidth:p.sensorWidth,sensorHeight:p.sensorHeight})}>{p.name}</button>)}</div></div>
    </section>

    <section className="viewer card">
      <div className="viewer-top"><span><span className="live-dot"/> LIVE OPTICAL PREVIEW</span><span>{settings.focalLength}mm • f/{settings.aperture.toFixed(1)}</span></div>
      <div className="scene">
        <div className="scene-sky"/><div className="scene-glow"/>
        <div className="mountain back"/>
        <div className="mountain mid"/>
        <div className="tree t1"/><div className="tree t2"/><div className="tree t3"/>
        <div className="subject"><div className="head"/><div className="body-shape"/><div className="focus-ring"><Target size={20}/></div></div>
        <div className="foreground-leaf l1"/><div className="foreground-leaf l2"/>
        <div className="focus-plane" style={{left:`${Math.min(86,Math.max(14,45 + Math.log10(settings.focusDistance)*15))}%`}}/>
        <div className="focus-label">FOCUS {settings.focusDistance.toFixed(1)}m</div>
        <div className="vignette"/>
      </div>
      <div className="focus-scale"><span>0 m</span><div className="scale-line"><i/><i className="focus-marker"/></div><span>{Math.max(10,Math.round(settings.focusDistance*3))} m</span></div>
      {comparison.length>0 && <div className="compare-strip">{comparison.map((c,i)=><span key={i}>● {c.label}: {c.settings.focalLength}mm / f{c.settings.aperture}</span>)}</div>}
    </section>

    <section className="analysis-card card">
      <div className="card-head"><div><p className="eyebrow">ANALYSIS</p><h3>Depth of field</h3></div><Gauge size={20}/></div>
      <div className="metric hero-metric"><span>Total DoF</span><strong>{fmt(result.totalDof)}</strong><small>at {settings.focusDistance.toFixed(1)}m focus distance</small></div>
      <div className="metric-grid"><div className="metric"><span>Near limit</span><strong>{fmt(result.nearLimit)}</strong></div><div className="metric"><span>Far limit</span><strong>{fmt(result.farLimit)}</strong></div><div className="metric"><span>Hyperfocal</span><strong>{fmt(result.hyperfocal)}</strong></div><div className="metric"><span>Field of view</span><strong>{result.fov.toFixed(1)}°</strong></div></div>
      <div className="bar-analysis"><div className="bar-label"><span>Front / rear DoF</span><b>{Number.isFinite(result.totalDof)?`${((settings.focusDistance-result.nearLimit)/result.totalDof*100).toFixed(0)}% / ${((result.farLimit-settings.focusDistance)/result.totalDof*100).toFixed(0)}%`:"Open"}</b></div><div className="dof-bar"><i style={{width:`${Number.isFinite(result.totalDof)?Math.max(8,Math.min(92,100*result.totalDof/(settings.focusDistance+result.totalDof))):90}%`}}/></div></div>
      <div className="formula"><span>Circle of confusion</span><b>{result.coc.toFixed(3)} mm</b></div>
      <div className="formula"><span>Magnification</span><b>{result.magnification.toFixed(3)}×</b></div>
      <div className="info-box"><Sparkles size={16}/><span>Lower f-numbers create a shallower focus zone and stronger background separation.</span></div>
    </section>
  </div>
}

function Saved({saved,load,remove}:{saved:any[],load:(x:any)=>void,remove:(id:number)=>void}) {
  return <div className="content-card card"><div className="table-head"><h3>Your simulations</h3><span>{saved.length} saved</span></div>{saved.length===0?<Empty icon={<Save/>} text="No saved simulations yet. Tune the simulator and click Save."/>:<div className="project-list">{saved.map(s=><div className="project" key={s.id}><div className="project-icon"><Focus/></div><div><b>{s.name}</b><small>{s.focalLength}mm • f/{s.aperture} • focus {s.focusDistance}m</small></div><div className="project-metric"><span>DoF</span><b>{s.totalDof?s.totalDof.toFixed(2)+"m":"∞"}</b></div><button className="icon-btn" onClick={()=>load(s)}><ChevronRight/></button><button className="icon-btn danger" onClick={()=>remove(s.id)}><Trash2/></button></div>)}</div>}</div>
}

function Presets({load}:{load:(p:any)=>void}) {
  return <div className="preset-grid">{presets.map(p=><button className="preset-card card" key={p.name} onClick={()=>load(p)}><div className="preset-art"><Aperture size={32}/></div><div><span>{p.category}</span><h3>{p.name}</h3><p>{p.focalLength}mm · f/{p.aperture} · {p.focusDistance}m</p></div><ChevronRight/></button>)}</div>
}

function Catalog() {
  const [tab,setTab]=useState<"cameras"|"lenses">("cameras");
  const [items,setItems]=useState<any[]>([]);
  const [query,setQuery]=useState("");
  const [showForm,setShowForm]=useState(false);
  const [editing,setEditing]=useState<any|null>(null);
  const [form,setForm]=useState<any>({});
  const load=()=>api(tab==="cameras"?"/cameras":"/lenses").then(setItems).catch(()=>setItems([]));
  useEffect(()=>{load(); setQuery(""); setShowForm(false); setEditing(null)},[tab]);

  const filtered=items.filter(x => `${x.manufacturer||""} ${x.name||""} ${x.model||""}`.toLowerCase().includes(query.toLowerCase()));

  function beginNew(){
    setEditing(null);
    setForm(tab==="cameras"
      ? {manufacturer:"",model:"",sensorType:"Full Frame",sensorWidth:36,sensorHeight:24,cropFactor:1,megapixels:"",mount:""}
      : {manufacturer:"",model:"",focalMin:50,focalMax:50,maxAperture:2.8,minFocusDistance:0.5,mount:""});
    setShowForm(true);
  }
  function beginEdit(x:any){
    setEditing(x); setForm({...x}); setShowForm(true);
  }
  async function save(){
    const endpoint=tab==="cameras"?"/cameras":"/lenses";
    const method=editing?"PUT":"POST";
    const path=editing?`${endpoint}/${editing.id}`:endpoint;
    await api(path,{method,body:JSON.stringify({...form,name:`${form.manufacturer||""} ${form.model||""}`.trim()})});
    setShowForm(false); setEditing(null); await load();
  }
  async function customize(x:any){
    const copy=tab==="cameras"
      ? {manufacturer:x.manufacturer,model:x.model,sensorType:x.sensorType,sensorWidth:x.sensorWidth,sensorHeight:x.sensorHeight,cropFactor:x.cropFactor,megapixels:x.megapixels,mount:x.mount}
      : {manufacturer:x.manufacturer,model:x.model,focalMin:x.focalMin,focalMax:x.focalMax,maxAperture:x.maxAperture,minFocusDistance:x.minFocusDistance,mount:x.mount};
    const created=await api(tab==="cameras"?"/cameras":"/lenses",{method:"POST",body:JSON.stringify({...copy,name:`${copy.manufacturer} ${copy.model}`})});
    setItems(v=>[created,...v]);
  }
  async function remove(x:any){
    if(!confirm(`Delete your custom ${tab === "cameras" ? "camera" : "lens"} "${x.name}"?`)) return;
    await api(`/${tab}/${x.id}`,{method:"DELETE"}); load();
  }

  return <div className="content-card card">
    <div className="card-head">
      <div><p className="eyebrow">PROFESSIONAL CATALOG</p><h3>Camera & Lens Library</h3><small>{items.filter(x=>x.isCatalog).length} manufacturer entries · {items.filter(x=>!x.isCatalog).length} personal custom entries</small></div>
      <button className="primary" onClick={beginNew}><Plus size={16}/> Add Custom</button>
    </div>
    <div className="tabbar">
      <button className={tab==="cameras"?"selected":""} onClick={()=>setTab("cameras")}>Cameras</button>
      <button className={tab==="lenses"?"selected":""} onClick={()=>setTab("lenses")}>Lenses</button>
      <label className="catalog-search"><Search size={15}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={`Search ${tab}...`}/></label>
    </div>
    {showForm && <div className="catalog-editor card">
      <div className="card-head"><div><p className="eyebrow">{editing?"EDIT CUSTOM":"NEW CUSTOM"}</p><h3>{editing?"Customize your entry":"Add to your personal catalog"}</h3></div><button className="icon-btn" onClick={()=>setShowForm(false)}><X/></button></div>
      {tab==="cameras" ? <div className="form-grid">
        <label>Manufacturer<input value={form.manufacturer||""} onChange={e=>setForm({...form,manufacturer:e.target.value})}/></label>
        <label>Model<input value={form.model||""} onChange={e=>setForm({...form,model:e.target.value})}/></label>
        <label>Sensor Type<input value={form.sensorType||""} onChange={e=>setForm({...form,sensorType:e.target.value})}/></label>
        <label>Sensor Width (mm)<input type="number" value={form.sensorWidth} onChange={e=>setForm({...form,sensorWidth:Number(e.target.value)})}/></label>
        <label>Sensor Height (mm)<input type="number" value={form.sensorHeight} onChange={e=>setForm({...form,sensorHeight:Number(e.target.value)})}/></label>
        <label>Crop Factor<input type="number" step="0.01" value={form.cropFactor} onChange={e=>setForm({...form,cropFactor:Number(e.target.value)})}/></label>
        <label>Megapixels<input type="number" step="0.1" value={form.megapixels||""} onChange={e=>setForm({...form,megapixels:e.target.value?Number(e.target.value):null})}/></label>
        <label>Mount<input value={form.mount||""} onChange={e=>setForm({...form,mount:e.target.value})}/></label>
      </div> : <div className="form-grid">
        <label>Manufacturer<input value={form.manufacturer||""} onChange={e=>setForm({...form,manufacturer:e.target.value})}/></label>
        <label>Model<input value={form.model||""} onChange={e=>setForm({...form,model:e.target.value})}/></label>
        <label>Focal Min (mm)<input type="number" value={form.focalMin} onChange={e=>setForm({...form,focalMin:Number(e.target.value)})}/></label>
        <label>Focal Max (mm)<input type="number" value={form.focalMax} onChange={e=>setForm({...form,focalMax:Number(e.target.value)})}/></label>
        <label>Max Aperture<input type="number" step="0.1" value={form.maxAperture} onChange={e=>setForm({...form,maxAperture:Number(e.target.value)})}/></label>
        <label>Min Focus (m)<input type="number" step="0.01" value={form.minFocusDistance} onChange={e=>setForm({...form,minFocusDistance:Number(e.target.value)})}/></label>
        <label>Mount<input value={form.mount||""} onChange={e=>setForm({...form,mount:e.target.value})}/></label>
      </div>}
      <div className="head-actions"><button className="secondary" onClick={()=>setShowForm(false)}>Cancel</button><button className="primary" onClick={save}>{editing?"Save Changes":"Add to My Catalog"}</button></div>
    </div>}
    <div className="catalog-list">
      {filtered.length===0?<Empty icon={<Camera/>} text={`No ${tab} match your search.`}/>:filtered.map(x=><div className="catalog-row" key={x.id}>
        <Camera/><div className="catalog-main"><b>{x.name}</b><small>{x.isCatalog?"Manufacturer catalog":"My custom catalog"} · {tab==="cameras"?`${x.sensorType} · ${x.sensorWidth}×${x.sensorHeight}mm${x.megapixels?` · ${x.megapixels}MP`:""}`:`${x.focalMin}–${x.focalMax}mm · f/${x.maxAperture} · ${x.mount||"—"}`}</small></div>
        {x.isCatalog ? <button className="secondary small" onClick={()=>customize(x)}><Copy size={14}/> Customize</button> :
          <><button className="icon-btn" onClick={()=>beginEdit(x)} title="Edit"><Pencil size={15}/></button><button className="icon-btn" onClick={()=>remove(x)} title="Delete"><Trash2 size={15}/></button></>}
      </div>)}
    </div>
  </div>
}
function Analytics({saved}:{saved:any[]}) {
  const avg=saved.length?saved.reduce((a,s)=>a+(s.fov||0),0)/saved.length:0;
  return <div className="analytics-grid"><div className="stat-card card"><span>Saved simulations</span><strong>{saved.length}</strong><small>Personal workspace</small></div><div className="stat-card card"><span>Average FOV</span><strong>{avg.toFixed(1)}°</strong><small>Across saved setups</small></div><div className="stat-card card"><span>Optical presets</span><strong>{presets.length}</strong><small>Ready to explore</small></div><div className="insight card"><ChartNoAxesCombined size={22}/><div><b>Your optical workspace</b><p>Save several setups to build a personal reference library for portraits, landscapes, macro and cinematic work.</p></div></div></div>
}

function SettingsPanel({theme,setTheme,user}:{theme:string,setTheme:(x:string)=>void,user:User}) {
  return <div className="settings-grid"><div className="content-card card"><div className="card-head"><div><p className="eyebrow">PROFILE</p><h3>Account</h3></div><CircleUserRound/></div><div className="profile-block"><div className="avatar">{user.name.charAt(0).toUpperCase()}</div><div><h3>{user.name}</h3><p>{user.email}</p><span className="badge">{user.role}</span></div></div></div><div className="content-card card"><div className="card-head"><div><p className="eyebrow">APPEARANCE</p><h3>Workspace</h3></div><Settings/></div><div className="setting-row"><div><b>Theme</b><small>Choose how DoF Studio looks</small></div><div className="select-row"><button className={theme==="dark"?"selected":""} onClick={()=>setTheme("dark")}><Moon size={15}/> Dark</button><button className={theme==="light"?"selected":""} onClick={()=>setTheme("light")}><Sun size={15}/> Light</button></div></div><div className="setting-row"><div><b>Data storage</b><small>Account data is persisted in MySQL</small></div><span className="connected"><Database size={15}/> Connected</span></div></div></div>
}

function Empty({icon,text}:{icon:React.ReactNode,text:string}) { return <div className="empty">{icon}<p>{text}</p></div> }
