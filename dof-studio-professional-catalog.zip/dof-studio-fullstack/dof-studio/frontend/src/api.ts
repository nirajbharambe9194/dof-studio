const API = import.meta.env.VITE_API_URL || "http://localhost:4000/api";

export async function api(path: string, options: RequestInit = {}) {
  const token = localStorage.getItem("dof_token");
  const headers = new Headers(options.headers);
  headers.set("Content-Type", "application/json");
  if (token) headers.set("Authorization", `Bearer ${token}`);
  const response = await fetch(`${API}${path}`, { ...options, headers });
  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.message || "Request failed");
  }
  return response.status === 204 ? null : response.json();
}
