export type DofSettings = {
  focalLength: number;
  aperture: number;
  focusDistance: number;
  sensorWidth: number;
  sensorHeight: number;
};

export function calculate(s: DofSettings) {
  // Standard thin-lens photographic DoF approximation.
  const coc = Math.max(0.005, s.sensorWidth / 1500);
  const f = s.focalLength;
  const N = Math.max(0.1, s.aperture);
  const u = Math.max(f * 1.01, s.focusDistance * 1000);
  const H = (f * f) / (N * coc) + f;
  const near = (H * u) / (H + (u - f));
  const far = u < H ? (H * u) / (H - (u - f)) : Infinity;
  const total = far === Infinity ? Infinity : far - near;
  const fov = 2 * Math.atan(s.sensorWidth / (2 * f)) * 180 / Math.PI;
  const magnification = f / Math.max(1, u - f);
  return {
    coc,
    hyperfocal: H / 1000,
    nearLimit: near / 1000,
    farLimit: far === Infinity ? Infinity : far / 1000,
    totalDof: total === Infinity ? Infinity : total / 1000,
    fov,
    magnification
  };
}

export const presets = [
  { name: "Portrait", category: "People", focalLength: 85, aperture: 1.8, focusDistance: 2.5, sensorWidth: 36, sensorHeight: 24 },
  { name: "Landscape", category: "Nature", focalLength: 24, aperture: 8, focusDistance: 8, sensorWidth: 36, sensorHeight: 24 },
  { name: "Macro", category: "Close-up", focalLength: 100, aperture: 5.6, focusDistance: 0.5, sensorWidth: 36, sensorHeight: 24 },
  { name: "Street", category: "Urban", focalLength: 35, aperture: 4, focusDistance: 4, sensorWidth: 36, sensorHeight: 24 },
  { name: "Cinematic", category: "Film", focalLength: 50, aperture: 1.4, focusDistance: 3, sensorWidth: 36, sensorHeight: 24 }
];
